<?php

class common {
    
    /**
     * Token generation
     * @param type $apikey
     * @return type
     */
    function identify($apikey) { 
        $idUrl = "https://identity-uat.ngenius-payments.com/auth/realms/ni/protocol/openid-connect/token";
        $idHead = array("Authorization: Basic " . $apikey, "Content-Type: application/x-www-form-urlencoded");
        $idPost = http_build_query(array('grant_type' => 'client_credentials'));
        $idOutput = $this->invokeCurlRequest("POST", $idUrl, $idHead, $idPost);
        $idOutput = json_decode($idOutput);
        return $idOutput;
    }

    /**
     * Create Payment
     * @param type $session
     * @param type $access_token
     * @param type $outlet
     * @return type
     */
    function pay($session, $access_token, $outlet) {
        $ord = new stdClass;
        $ord->action = "SALE";
        $ord->amount['currencyCode'] = "AED";
        $ord->amount['value'] = 100;
        $ord = json_encode($ord);
        
        $payUrl = "https://api-gateway-uat.ngenius-payments.com/transactions/outlets/" . $outlet . "/payment/hosted-session/" . $session; 
        
        $payHead = array("Authorization: Bearer " . $access_token, "Content-Type: application/vnd.ni-payment.v2+json", "Accept: application/vnd.ni-payment.v2+json");
        $payOutput = $this->invokeCurlRequest("POST", $payUrl, $payHead, $ord);
        $payResponse = json_decode($payOutput);
        return $payResponse;
    }

    
    /**
     * Curl Request
     * @param type $type
     * @param type $url
     * @param type $headers
     * @param type $post
     * @return type
     */
    function invokeCurlRequest($type, $url, $headers, $post) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if ($type == "POST" || $type == "PUT") {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            if ($type == "PUT") {
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            }
        }
        $server_output = curl_exec($ch);//echo '<pre>';print_r($server_output);
        return $server_output;
    }

}

//End Class

