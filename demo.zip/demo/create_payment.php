<?php

include("includes/functions.php");

$outletRef = "5edab6d7-5946-43f4-b8c7-06b29c272bdd";
$apikey = "NWM0NGI5MTUtMTZkMS00YjBmLTljYmQtOWM1ZDM5NTlhM2M2OjJmOTM5MDExLWNlNzUtNDcyMS05MzI1LWYzYWJmNTI1Y2Y3MQ==";
$obj = new common;

//if (isset($_REQUEST['session_id'])) {
    $session = $_REQUEST['session_id'];
    $session_id = $_SESSION[$session];
    try {
        $idData = $obj->identify($apikey);
        if (isset($idData->access_token)) {
            $token = $idData->access_token;
            $payData = $obj->pay($session, $token, $outletRef);
            echo json_encode($payData);exit;
            //echo '<pre>';print_r($payData);
        }
    } catch (Exception $e) {
        echo($e->getMessage());
    }
//}
?>